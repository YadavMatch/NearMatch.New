# Report User Feature Implementation Plan

Implement a robust 'Report User' feature within the chat view (`MatchesChatView.tsx`) that allows verified users to flag a conversation or profile for safety review, persist the report in Firestore (`reports`), and optionally block the user automatically as requested.

## User Review & Critical Decisions

> [!IMPORTANT]
> - **Confirmed Decision 1**: Primary report categories include harassment, fake profile, inappropriate content/spam, and other safety concerns.
> - **Confirmed Decision 2**: Submitting a report automatically blocks the user and removes them from active conversations to ensure immediate safety.

---

## 1. Overview & Core Concept

- **What It Does**: Adds a 'Report User' button in the chat view header and profile modal that opens a safety reporting form. Submitting writes a secure record to the `reports` Firestore collection and triggers an automatic block.
- **Target Audience**: Verified NearMatch members seeking safe reporting tools.
- **Key Value**: Preserves community safety with auditable reports and immediate blocking.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. User clicks the 'Report' button in chat header or profile view.
  2. Modal opens asking for reporting reason and optional details.
  3. Upon submission, report is saved to Firestore, user is blocked, conversation is closed, and confirmation notice is shown.
- **Visual Identity**: Warm coral and cream theme (`#E8603A`, `#FFF8EC`), clear typography, accessible modal with focus trapping and keyboard support.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1**: Server-side validation via `firestore.rules` and `firebase-blueprint.json`.
  - *Chosen Approach*: Add `Report` entity to blueprint, enforce strict validation rules (`reporterId == request.auth.uid`, size limits), and deploy rules.
  - *Why*: Prevents unauthorized or spam reports while protecting user privacy.

---

## 4. Technical Architecture & Data Strategy

```
[MatchesChatView / ProfileDetailModal]
           │
           ▼
[submitReport & blockUser in firestoreService.ts]
           │
           ├────────────────────────┐
           ▼                        ▼
[Firestore: /reports/{id}]   [Firestore: /blocks/{id}]
           │                        │
           └────────────────────────┘
                       │
             [Deploy Firestore Rules]
```

- **Data Model & State**:
  - `reports` collection: `reporterId`, `reportedId`, `matchId` / `conversationId`, `reason`, `details`, `status` ('open'), `createdAt`.
- **Security Rules**:
  - Only authenticated, verified users can create reports where `reporterId == request.auth.uid`.
